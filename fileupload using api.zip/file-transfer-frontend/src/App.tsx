import React, { useState } from 'react';
import FileSender from './components/FileSender';
import FileReceiver from './components/Reciever';
import './App.css';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'send' | 'receive'>('send');

  return (
    <div className="app-container">
      <h1>File Transfer Application</h1>
      
      <div className="tab-container">
        <button
          className={`tab-button ${activeTab === 'send' ? 'active' : ''}`}
          onClick={() => setActiveTab('send')}
        >
          Send Files
        </button>
        <button
          className={`tab-button ${activeTab === 'receive' ? 'active' : ''}`}
          onClick={() => setActiveTab('receive')}
        >
          Receive Files
        </button>
      </div>

      <div className="content-area">
        {activeTab === 'send' ? <FileSender /> : <FileReceiver />}
      </div>

      <div className="app-info">
        <p>Using HTTP-based file transfer with chunking and verification</p>
        <p>Server: http://localhost:8080</p>
      </div>
    </div>
  );
};

export default App;