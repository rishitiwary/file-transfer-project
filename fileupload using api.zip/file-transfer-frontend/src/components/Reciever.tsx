import React, { useState, useEffect } from 'react';

interface Transfer {
  transferId: string;
  fileName: string;
  fileSize: number;
  totalChunks: number;
  receivedChunks: number;
  progress: number;
  completed: boolean;
}

const FileReceiver: React.FC = () => {
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [downloading, setDownloading] = useState<string | null>(null);

  const fetchTransfers = async () => {
    try {
      const response = await fetch('http://localhost:8080/transfers');
      if (!response.ok) throw new Error('Server error');
      
      const data = await response.json();
      setTransfers(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch transfers. Is the server running?');
      console.error('Fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransfers();
    const interval = setInterval(fetchTransfers, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleDownload = async (transferId: string, fileName: string) => {
    try {
      setDownloading(transferId);
      
      // Create a hidden anchor element
      const a = document.createElement('a');
      a.href = `http://localhost:8080/download/${transferId}`;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      
      // Clean up
      setTimeout(() => {
        document.body.removeChild(a);
        setDownloading(null);
      }, 100);
    } catch (err) {
      console.error('Download failed:', err);
      setError('Download failed. Please try again.');
      setDownloading(null);
    }
  };

  if (loading) return <div className="status">Loading transfers...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="receiver">
      <h2>File Receiver</h2>
      
      <div className="transfer-list">
        <h3>Available Transfers</h3>
        <button onClick={fetchTransfers} className="refresh-button">
          Refresh List
        </button>

        {transfers.length === 0 ? (
          <div className="empty-state">
            <p>No transfers available</p>
            <p className="hint">
              Make sure the sender has completed the upload using the correct transfer code
            </p>
          </div>
        ) : (
          <ul>
            {transfers.map((transfer) => (
              <li key={transfer.transferId} className="transfer-item">
                <div className="transfer-info">
                  <span className="filename">{transfer.fileName}</span>
                  <span className="size">({(transfer.fileSize / 1024 / 1024).toFixed(2)} MB)</span>
                  <div className="progress-container">
                    <progress 
                      value={transfer.receivedChunks} 
                      max={transfer.totalChunks}
                    />
                    <span>{Math.round(transfer.progress * 100)}%</span>
                  </div>
                </div>
                <button
                  onClick={() => handleDownload(transfer.transferId, transfer.fileName)}
                  disabled={!transfer.completed || downloading === transfer.transferId}
                  className={`download-button ${
                    transfer.completed 
                      ? downloading === transfer.transferId 
                        ? 'downloading' 
                        : 'active' 
                      : 'disabled'
                  }`}
                >
                  {downloading === transfer.transferId 
                    ? 'Downloading...' 
                    : transfer.completed 
                      ? 'Download' 
                      : 'In Progress'}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default FileReceiver;