import React, { useState, useCallback, useRef } from 'react';
import CryptoJS from 'crypto-js';

const CHUNK_SIZE = 5 * 1024 * 1024; // 5MB chunks

interface ChunkManifest {
  index: number;
  size: number;
  hash: string;
}

interface FileManifest {
  fileName: string;
  fileSize: number;
  totalChunks: number;
  chunks: ChunkManifest[];
}

const FileSender: React.FC = () => {
  const [fileToSend, setFileToSend] = useState<File | null>(null);
  const [transferCode, setTransferCode] = useState('');
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('Select a file to begin');
  const [logs, setLogs] = useState<string[]>([]);
  const [isTransferring, setIsTransferring] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  const addLog = useCallback((message: string) => {
    const timestamped = `${new Date().toLocaleTimeString()} - ${message}`;
    setLogs(prev => [...prev.slice(-100), timestamped]); // Keep last 100 logs
    console.log(timestamped);
  }, []);

  const calculateHash = async (chunk: Blob): Promise<string> => {
    const arrayBuffer = await chunk.arrayBuffer();
    const wordArray = CryptoJS.lib.WordArray.create(arrayBuffer);
    return CryptoJS.MD5(wordArray).toString();
  };

  const generateFileManifest = async (file: File): Promise<FileManifest> => {
    const chunks: ChunkManifest[] = [];
    let offset = 0;
    let index = 0;

    while (offset < file.size) {
      const chunk = file.slice(offset, offset + CHUNK_SIZE);
      const hash = await calculateHash(chunk);

      chunks.push({
        index,
        size: chunk.size,
        hash
      });

      offset += chunk.size;
      index++;
    }

    return {
      fileName: file.name,
      fileSize: file.size,
      totalChunks: chunks.length,
      chunks
    };
  };

  const uploadChunk = async (
    transferId: string,
    chunk: Blob,
    index: number,
    hash: string,
    retryCount = 0
  ): Promise<boolean> => {
    if (abortControllerRef.current?.signal.aborted) {
      return false;
    }

    try {
      const formData = new FormData();
      formData.append('chunk', chunk);
      formData.append('chunkIndex', index.toString());
      formData.append('transferId', transferId);

      const controller = new AbortController();
      abortControllerRef.current = controller;

      const response = await fetch(`http://localhost:8080/upload-chunk/${transferId}`, {
        method: 'POST',
        body: formData,
        signal: controller.signal
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      return true;
    } catch (error) {
      if (retryCount < 3 && !(error instanceof DOMException)) {
        addLog(`Retrying chunk ${index} (attempt ${retryCount + 1})`);
        await new Promise(resolve => setTimeout(resolve, 1000 * (retryCount + 1)));
        return uploadChunk(transferId, chunk, index, hash, retryCount + 1);
      }
      addLog(`Failed to upload chunk ${index}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return false;
    }
  };

  const initiateTransfer = async (manifest: FileManifest): Promise<string> => {
    const response = await fetch('http://localhost:8080/initiate-transfer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        transferCode,
        fileName: manifest.fileName,
        fileSize: manifest.fileSize,
        totalChunks: manifest.totalChunks
      })
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || 'Failed to initiate transfer');
    }

    const data = await response.json();
    return data.transferId;
  };

  const finalizeTransfer = async (transferId: string) => {
    const response = await fetch(`http://localhost:8080/finalize-transfer/${transferId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      throw new Error('Failed to finalize transfer');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileToSend(file);
      setStatus('File selected - ready to transfer');
      setProgress(0);
      addLog(`Selected file: ${file.name} (${(file.size / (1024 * 1024)).toFixed(2)} MB)`);
    }
  };

  const abortTransfer = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setStatus('Transfer cancelled');
      addLog('Transfer was cancelled by user');
      setIsTransferring(false);
    }
  };

  const handleTransfer = async () => {
    if (!fileToSend || !transferCode.trim()) {
      addLog('Please select a file and enter a transfer code');
      return;
    }

    try {
      setIsTransferring(true);
      abortControllerRef.current = new AbortController();
      
      setStatus('Preparing file...');
      addLog('Generating file manifest...');
      const manifest = await generateFileManifest(fileToSend);
      addLog(`File divided into ${manifest.totalChunks} chunks`);

      setStatus('Creating transfer session...');
      const transferId = await initiateTransfer(manifest);
      addLog(`Transfer session created: ${transferId}`);

      setStatus('Uploading chunks...');
      setProgress(0);

      // Upload chunks with parallel connections
      const parallelUploads = 3;
      const chunkGroups: number[][] = [];
      for (let i = 0; i < manifest.totalChunks; i += parallelUploads) {
        chunkGroups.push(
          Array.from({ length: parallelUploads }, (_, j) => i + j)
            .filter(idx => idx < manifest.totalChunks)
        );
      }

      for (const group of chunkGroups) {
        if (abortControllerRef.current?.signal.aborted) break;

        const results = await Promise.all(group.map(async (chunkIndex) => {
          const chunk = manifest.chunks[chunkIndex];
          const chunkBlob = fileToSend.slice(
            chunkIndex * CHUNK_SIZE,
            Math.min((chunkIndex + 1) * CHUNK_SIZE, fileToSend.size)
          );

          const success = await uploadChunk(
            transferId,
            chunkBlob,
            chunkIndex,
            chunk.hash
          );

          if (success) {
            setProgress(prev => {
              const newProgress = prev + (100 / manifest.totalChunks);
              return Math.min(newProgress, 100);
            });
          }
          return success;
        }));

        if (results.some(success => !success)) {
          throw new Error('Some chunks failed to upload');
        }
      }

      if (abortControllerRef.current?.signal.aborted) {
        return;
      }

      setStatus('Finalizing transfer...');
      await finalizeTransfer(transferId);
      setStatus('Transfer completed successfully!');
      addLog(`File "${manifest.fileName}" transferred successfully`);
    } catch (error) {
      if (!(error instanceof DOMException)) { // Ignore abort errors
        setStatus('Transfer failed');
        addLog(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
        console.error('Transfer error:', error);
      }
    } finally {
      setIsTransferring(false);
      abortControllerRef.current = null;
    }
  };

  return (
    <div className="sender">
      <h2>File Sender</h2>
      
      <div className="file-selector">
        <input
          type="file"
          onChange={handleFileChange}
          id="fileInput"
          disabled={isTransferring}
          accept="*"
        />
        <label htmlFor="fileInput" className="file-label">
          {fileToSend ? fileToSend.name : 'Choose File'}
        </label>
      </div>

      <div className="transfer-code">
        <input
          type="text"
          value={transferCode}
          onChange={(e) => setTransferCode(e.target.value)}
          placeholder="Enter transfer code"
          disabled={isTransferring}
        />
      </div>

      <div className="button-group">
        <button 
          onClick={handleTransfer}
          disabled={!fileToSend || !transferCode.trim() || isTransferring}
          className="transfer-button"
        >
          {isTransferring ? 'Transferring...' : 'Start Transfer'}
        </button>
        
        {isTransferring && (
          <button 
            onClick={abortTransfer}
            className="abort-button"
          >
            Cancel Transfer
          </button>
        )}
      </div>

      <div className="progress-container">
        <div className="status">{status}</div>
        <progress value={progress} max="100" />
        <div className="progress-text">{Math.round(progress)}%</div>
      </div>

      <div className="transfer-logs">
        <h3>Transfer Log</h3>
        <div className="log-content">
          {logs.length === 0 ? (
            <div className="empty-logs">No activity yet</div>
          ) : (
            logs.map((log, index) => (
              <div key={index} className="log-entry">{log}</div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default FileSender;