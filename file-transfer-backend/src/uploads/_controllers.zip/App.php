<?php
error_reporting(0);
defined('BASEPATH') or exit('No direct script access allowed');

require_once(APPPATH . 'third_party/vendor/autoload.php');
use Razorpay\Api\Api;
class App extends CI_Controller
{

    public $status;
    public $roles;

    function __construct()
    {
        parent::__construct();
        $this->load->model('User_model', 'user_model', TRUE);
        $this->load->model('Basic_operation', 'basic_operation', TRUE);
        $this->load->model('Auth', 'auth', TRUE);
        $this->load->model('AdminDetails');
        $this->load->library('form_validation');
        $this->load->library('user_agent');
        $this->status = $this->config->item('status');
        $this->roles = $this->config->item('roles');
        $this->load->library('userlevel');
        $this->load->model('Commonmodel');
          $this->api = new Api('rzp_live_QkaMpUNBYhZzQU', 'DEvyk6V3gtZUTfX2L7DxMfU2');
    }

    //index dasboard
    public function index()
    {
        //user data from session
        $data = $this->session->userdata;
        if (empty($data)) {
            redirect(site_url() . 'main/login/');
        }

        //check user level
        if (empty($data['role'])) {
            redirect(site_url() . 'main/login/');
        }
        $dataLevel = $this->userlevel->checkLevel($data['role']);
        //check user level

        $data['title'] = "Dashboard User";

        if (empty($this->session->userdata['email'])) {
            redirect(site_url() . 'main/login/');
        } else {

            $this->load->view('index', $data);
        }
    }


    //register new user from frontend
    public function register()
    {

        $pass = md5($this->input->post('pass'));
        $confirm_pass = md5($this->input->post('confirm_password'));
        if ($pass != $confirm_pass) {
            $array = array(
                'error'    => true,
                'message' => 'Confirm password is not matched'
            );
        }
        if ($this->auth->isDuplicate('email',$this->input->post('email'))) {
            // email duplicate response
            $array = array(
                'error'    => true,
                'message' => 'User email already exists'
            );
        }elseif ($this->auth->isDuplicate('phone',$this->input->post('phone'))) {
            // phone duplicate response
            $array = array(
                'error'    => true,
                'message' => 'User number already exists'
            );
        } else {

            $form_data = array(
                'username' => $this->input->post('username'),
                'address' => $this->input->post('address'),
                'email'   => $this->input->post('email'),
                'pass'  => md5($this->input->post('pass')),
                'phone'  => $this->input->post('phone'),
                'device_type' => $this->input->post('device_type'),

            );


            //insert to database
            $id = $this->auth->insertUser($form_data);
            $token = $this->auth->insertToken($id);
            if ($id) {
                // success response
                $array = array(
                    'error'    => false,
                    'message' => 'Registerd Successfully.'
                );
            } else {
                // error response
                $array = array(
                    'error'    => true,
                    'message' => 'There was a problem.'
                );
            }
        }

        echo json_encode($array);
    }



    //if success after set password
    public function successresetpassword()
    {
        $data['title'] = "Success Reset Password";
        $this->load->view('header', $data);
        $this->load->view('container');
        $this->load->view('reset-pass-info');
        $this->load->view('footer');
    }

    protected function _islocal()
    {
        return strpos($_SERVER['HTTP_HOST'], 'local');
    }

    //check if complate after add new user
    public function complete()
    {
        $token = base64_decode($this->uri->segment(4));

        $user_info = $this->user_model->isTokenValid($token);
        if (!$user_info) {
            echo 'Token is invalid or expired';
        } else {
            $data = array(
                'name' => $user_info->name,
                'email' => $user_info->email,
                'user_id' => $user_info->id,
                'token' => $this->base64url_encode($token)
            );
            $this->user_model->updateUserInfo($data);
            header("refresh:5;url='" . site_url() . "");
            echo 'Account activated now you can login...';
            exit;
        }
    }

    public function verifyOTP()
    {

        if ($this->input->server('REQUEST_METHOD') == 'POST' && !empty($this->input->post('mobile')) && !empty($this->input->post('otp'))) {
            $otp = $this->input->post('otp');
            $mobile = $this->input->post('mobile');
            $chkOTP = $this->AdminDetails->fetchCol_Con("mst_user", 'id,otp', "phone=$mobile and otp=$otp");
            if ($chkOTP[0]->id != '') {
                $data = array(
                    'otp' => 0,
                    'fcm_token' => $this->input->post('fcm_token'),
                    'device_type' => $this->input->post('device_type'),
                    'deviceId' => trim($this->input->post('deviceId')),
                );
                $update = $this->AdminDetails->updateDetails("mst_user", $data, "phone=$mobile");

                $userInfo = $this->AdminDetails->fetchCol_Con("mst_user", "id,username,email,phone,image,token,fcm_token", "phone=$mobile");
                $datas = array(

                    'mobileNumber' => $userInfo[0]->phone,
                    'fcmToken' => $this->input->post('fcm_token'),
                    'deviceType' => $this->input->post('device_type'),
                    'deviceId' => $this->input->post('deviceId'),
                    'androidVersion' => $this->input->post('androidVersion'),
                    'loginType' => 'mobile',
                    'cdate' => date('d-m-Y h:i:s')
                );
                $insert = $this->AdminDetails->insertData('auth_history', $datas);

                $array = array(
                    'error'    => false,
                    'message' => 'OTP Verified Successfully.',
                    'user_detail' => $userInfo[0]
                );
            } else {
                $array = array(
                    'error'    => true,
                    'message' => 'OTP is invalid'
                );
            }
        } else {
            $array = array(
                'error'    => true,
                'message' => 'mobile and otp field is required.'
            );
        }
        echo json_encode($array, true);
    }


    //check login failed or success
    public function login()
    {
        $this->load->library('curl');
        $data['title'] = "Welcome Back!";
        $form_data = array(
            'email'  => $this->input->post('email'),
            'pass'   => $this->input->post('pass'),
            'fcm_token' => $this->input->post('fcm_token'),
            'device_type' => $this->input->post('device_type'),
            'deviceId' => trim($this->input->post('deviceId')),
        );

        $userInfo = $this->user_model->checkLogin_appuser($form_data);



        if (!$userInfo) {

            $array = array(
                'status' => '403',
                'error'    => true,
                'message' => 'Some error occured.'
            );
        } else {
            $data = array(
                'mobileNumber' => $userInfo->phone,
                'fcmToken' => $this->input->post('fcm_token'),
                'deviceType' => $this->input->post('device_type'),
                'deviceId' => $this->input->post('deviceId'),
                'androidVersion' => $this->input->post('androidVersion'),
                'loginType' => 'mobile',
                'cdate' => date('d-m-Y h:i:s')
            );
            $insert = $this->AdminDetails->insertData('auth_history', $data);

            $array = array(
                'error'    => false,
                'message' => 'Login Successfully ! ',
                'token' => $userInfo->token,
                'user_detail' => $userInfo
            );
        }
        echo json_encode($array, true);
    }


    //Logout
    public function logout()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            if ($this->input->post('user_id')) {
                $data = array(
                    'is_login' => '0'
                );
                $this->db->where('id', $this->input->post('user_id'));
                $this->db->update("mst_user", $data);
                //   $this->db->where('id', $this->input->post('user_id'));
                if ($this->db->update('mst_user', array('deviceId' => ''))) {
                    $array = array(
                        'error'    => false,
                        'message' => 'Logged out successfully...! '
                    );


                    echo json_encode($array, true);
                }
            } else {
                $array = array(
                    'error'    => true,
                    'message' => 'token fiels is required '
                );
                echo json_encode($array, true);
            }
        }
    }

    //forgot password
    public function forgot()
    {
        $main_url = 'https://' . $_SERVER['HTTP_HOST'] . '/';
        $data['title'] = "Forgot Password";
        $this->load->library('curl');
        $this->load->library('recaptcha');
        // $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        $email = trim($this->input->post('email'));
        $userInfo = $this->user_model->getUserInfoByEmail($email);

        if (!$userInfo) {
            $form_data = array(
                'error'    => true,
                'message'  => 'User not registerd',
            );
        } else {

            //generate token
            $token = $this->user_model->insertToken($userInfo->id);
            $qstring = $this->base64url_encode($token);
            $url = $main_url . 'home/reset_password/token/' . $qstring;
            $link = '<a href="' . $url . '">' . $url . '</a>';

            $this->load->library('email');
            $this->load->library('Sendmail');

            $message = $this->sendmail->sendForgot($this->input->post('name'), $this->input->post('email'), $link, $sTl);

            $to_email = $this->input->post('email');
            $this->email->from($this->config->item('forgot'), 'Reset Password! ' . $this->input->post('name')); //from sender, title email
            $this->email->to($to_email);
            $this->email->subject('Reset Password');
            $this->email->message($message);
            $this->email->set_mailtype("html");

            if ($this->email->send()) {
                $form_data = array(
                    'error'    => false,
                    'message'  => 'Email sent successfully, please check your inbox',
                );
            } else {
                $errors = $this->email->print_debugger();
                print_r($errors);
                $form_data = array(
                    'error'    => true,
                    'message'  => 'There was a problem sending an email',
                );
            }
        }


        echo json_encode($form_data, true);
    }

    //reset password
    public function reset_password()
    {
        $token = $this->base64url_decode($this->uri->segment(4));
        $cleanToken = $this->security->xss_clean($token);
        $user_info = $this->user_model->isTokenValid($cleanToken); //either false or array();

        if (!$user_info) {
            echo 'Token is invalid or expired';
        }
        $data = array(
            'name' => $user_info->name,
            'email' => $user_info->email,
            //'user_id'=>$user_info->id,
            'token' => $this->base64url_encode($token)
        );

        $data['title'] = "Reset Password";
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');
        $this->form_validation->set_rules('passconf', 'Password Confirmation', 'required|matches[password]');


        // $this->load->library('password');
        $post = $this->input->post(NULL, TRUE);
        $cleanPost = $this->security->xss_clean($post);
        $hashed = $this->password->md5($cleanPost['password']);
        $cleanPost['password'] = $hashed;
        echo $cleanPost['user_id'] = $user_info->id;
        unset($cleanPost['passconf']);
        if (!$this->user_model->updatePassword($cleanPost)) {
            // $this->session->set_flashdata('flash_message', 'There was a problem updating your password');
            echo 'There was a problem updating your password';
        } else {
            // $this->session->set_flashdata('success_message', 'Your password has been updated. You may now login');
            echo 'Your password has been updated. You may now login';
        }
        // redirect(site_url().'app/checkLoginUser');


    }

    public function base64url_encode($data)
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    public function base64url_decode($data)
    {
        return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
    }

    public function resetpasswordcomplete()
    {
        $this->load->view('reset_password_completed');
        $this->load->view('footer');
    }
    public function resetpasswordfailed()
    {
        $this->load->view('reset_password_failed');
        $this->load->view('footer');
    }

    /*************************************************************** Home Page Data ****************************************************************/


    public function getHomeData()
    {
        $user_id = $this->input->post('user_id');

        $this->db->select('categories.*');
        $this->db->from('categories', 'categories.status=1');
        $this->db->where(['categories.parent_category' => '0', 'categories.id !=' => '95']);
        $Category = $this->db->get()->result();

        $this->db->select('promotional_category.*');
        $this->db->from('promotional_category', 'promotional_category.status=1');
        $this->db->where('promotional_category.status=1');
        $CategoryResults = $this->db->get()->result();
        foreach ($CategoryResults as $category) {
            $category_id = $category->id;
            $this->db->select('products.*,products.quantity as stock_quantity,products.id as product_id');
            $this->db->from('products');
            $this->db->where(['products.quantity >' => 0, 'products.status =' => 1, 'products.promotional_category' => $category_id]);
            $ProductResults = $this->db->get()->result();
            foreach ($ProductResults as $x) {
                $device_id = $this->input->post('device_id');
                $cartQtys = 0;
                if ($user_id > 0) {
                    $cartQty = $this->basic_operation->uniqueSelect('carts', array('user_id' => $user_id, 'product_id' => $x->product_id));
                    if (!empty($cartQty)) {
                        $cartQtys = $cartQty[0]->quantity;
                    }
                } else {
                    $cartQty = $this->basic_operation->uniqueSelect('carts', array('device_id' => $device_id, 'product_id' => $x->product_id));
                    if (!empty($cartQty)) {
                        $cartQtys = $cartQty[0]->quantity;
                    }
                }
                $x->cart_product_quantity = "$cartQtys";
                if ($cartQtys > 0) {
                    $x->CartStatus = '1';
                } else {
                    $x->CartStatus = '0';
                }
                if ($user_id > 0) {
                    $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('user_id' => $user_id, 'product_id' => $x->product_id));
                } else {
                    $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('device_id' => $device_id, 'product_id' => $x->product_id));
                }
                if ($favCounter > 0) {
                    $x->favourite_status = "1";
                } else {
                    $x->favourite_status = "0";
                }
            }
            $arr[] = array(
                'id' => $category->id,
                'title' => $category->category,
                'products' => $ProductResults
            );
        }

        $this->db->select('products.*,products.id as product_id, products.quantity as stock_quantity');
        $this->db->from('products');
        $this->db->where('products.status', 1);
        $this->db->order_by('products.id', 'desc');
        $this->db->limit(12);
        $newproducts = $this->db->get()->result();
        foreach ($newproducts as $x) {
            $device_id = $this->input->post('device_id');
            $cartQtys = 0;
            if ($user_id > 0) {
                $cartQty = $this->basic_operation->uniqueSelect('carts', array('user_id' => $user_id, 'product_id' => $x->id));
                if (!empty($cartQty)) {
                    $cartQtys = $cartQty[0]->quantity;
                }
            } else {
                $cartQty = $this->basic_operation->uniqueSelect('carts', array('device_id' => $device_id, 'product_id' => $x->id));
                if (!empty($cartQty)) {
                    $cartQtys = $cartQty[0]->quantity;
                }
            }
            $x->cart_product_quantity = "$cartQtys";
            if ($cartQtys > 0) {
                $x->CartStatus = '1';
            } else {
                $x->CartStatus = '0';
            }
            if ($user_id > 0) {
                $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('user_id' => $user_id, 'product_id' => $x->id));
            } else {
                $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('device_id' => $device_id, 'product_id' => $x->id));
            }
            if ($favCounter > 0) {
                $x->favourite_status = "1";
            } else {
                $x->favourite_status = "0";
            }
        }

        $collection = array(
            'error' => false,
            'message' => 'Request completed successfully',
            'category' => $Category,
            'data' => $arr,
            'newarrival' => $newproducts,
        );


        echo json_encode($collection);
    }

    public function getAllSubject()
    {
        $results = $this->AdminDetails->fetchSingleById('video_subject_tb', "1", 'status');

        $collection = array(
            'error' => false,
            'message' => 'Request completed successfully',
            'data' => $results,
        );
        echo json_encode($collection);
    }

    public function getAllUser()
    {
        $results = $this->AdminDetails->fetchAll('mst_user');
        $collection = array(
            'error' => false,
            'message' => 'Request completed successfully',
            'data' => $results,
        );
        echo json_encode($collection);
    }


    public function getAllOffer()
    {
        $user_id = $this->input->post('user_id');
        $limit = 10;
        (int)$start = $this->input->post('page') ? $this->input->post('page') : 0;
        $iosall = $this->input->post('iosall');
        $start *= $limit;
        // $this->db->select('offers.*,offers.quantity as stock_quantity');
        // $this->db->from('offers','offers.status=1');
        // $this->db->where('offers.status',1);
        $this->db->select('products.*,products.id as product_id, products.quantity as stock_quantity');
        $this->db->from('products');
        $this->db->where('products.status', 1);
        $this->db->where('products.offer_percentage >', 0);
        if ($iosall == '') {
            $this->db->limit($limit, $start);
        }
        $OfferProductResults = $this->db->get()->result();
        foreach ($OfferProductResults as $x) {
            $device_id = $this->input->post('device_id');
            $cartQtys = 0;
            if ($user_id > 0) {
                $cartQty = $this->basic_operation->uniqueSelect('carts', array('user_id' => $user_id, 'product_id' => $x->id));
                if (!empty($cartQty)) {
                    $cartQtys = $cartQty[0]->quantity;
                }
            } else {
                $cartQty = $this->basic_operation->uniqueSelect('carts', array('device_id' => $device_id, 'product_id' => $x->id));
                if (!empty($cartQty)) {
                    $cartQtys = $cartQty[0]->quantity;
                }
            }
            $x->cart_product_quantity = "$cartQtys";
            if ($cartQtys > 0) {
                $x->CartStatus = '1';
            } else {
                $x->CartStatus = '0';
            }
            if ($user_id > 0) {
                $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('user_id' => $user_id, 'product_id' => $x->id));
            } else {
                $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('device_id' => $device_id, 'product_id' => $x->id));
            }
            if ($favCounter > 0) {
                $x->favourite_status = "1";
            } else {
                $x->favourite_status = "0";
            }
        }
        $collection = array(
            'error' => false,
            'message' => 'Request completed successfully',
            'data' => $OfferProductResults,
        );
        echo json_encode($collection);
    }

    public function getAllCategoryProduct()
    {
        if ($this->input->post('category_id')) {
            $limit = 10;
            (int)$start = $this->input->post('page');
            $start *= $limit;
            $iosall = $this->input->post('iosall');
            $category_id = $this->input->post('category_id');
            $type = $this->input->post('type');
            $user_id = $this->input->post('user_id');

            if ($type == 'promotional') {
                $this->db->select('products.*,promotional_category.category as category, products.quantity as stock_quantity,products.id as product_id,categories.id as category_id');
                $this->db->from('products');
                $this->db->join('categories', 'categories.id=products.category_id');
                $this->db->join('promotional_category', 'promotional_category.id=products.promotional_category', 'left');
                $this->db->or_where('products.promotional_category', $category_id);
            } else {
                $this->db->select('products.*,categories.category,products.quantity as stock_quantity,products.id as product_id,categories.id as category_id');
                $this->db->from('products');
                $this->db->join('categories', 'categories.id=products.category_id');
                $where = '(categories.id="' . $category_id . '" or categories.parent_category = "' . $category_id . '")';
                $this->db->or_where($where);
            }


            // $this->db->where('products.category_id',$category_id);
            // $this->db->or_where(,$category_id);
            $this->db->where('products.status', 1);

            if ($iosall == '') {
                $this->db->limit($limit, $start);
            }
            $results = $this->db->get()->result();
            // print_r($results);
            // exit();
            $sale = $results;
            foreach ($sale as $x) {
                $device_id = $this->input->post('device_id');
                $cartQtys = 0;
                if ($user_id > 0) {
                    $cartQty = $this->basic_operation->uniqueSelect('carts', array('user_id' => $user_id, 'product_id' => $x->product_id));
                    if (!empty($cartQty)) {
                        $cartQtys = $cartQty[0]->quantity;
                    }
                } else {
                    $cartQty = $this->basic_operation->uniqueSelect('carts', array('device_id' => $device_id, 'product_id' => $x->product_id));
                    if (!empty($cartQty)) {
                        $cartQtys = $cartQty[0]->quantity;
                    }
                }
                $x->cart_product_quantity = "$cartQtys";
                if ($cartQtys > 0) {
                    $x->CartStatus = '1';
                } else {
                    $x->CartStatus = '0';
                }
                if ($user_id > 0) {
                    $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('user_id' => $user_id, 'product_id' => $x->product_id));
                } else {
                    $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('device_id' => $device_id, 'product_id' => $x->product_id));
                }
                if ($favCounter > 0) {
                    $x->favourite_status = "1";
                } else {
                    $x->favourite_status = "0";
                }
            }
            $collection = array(
                'error' => false,
                'message' => 'Request completed successfully',
                'data' => $sale,
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'category id & user id must be required',
            );
        }
        echo json_encode($collection);
    }


    public function getPromotionalCategoryProduct()
    {
        if ($this->input->post('category_id') && $this->input->post('user_id')) {
            $limit = 10;
            $start = $this->input->post('page');
            $start *= $limit;
            $iosall = $this->input->post('iosall');
            $category_id = $this->input->post('category_id');
            $user_id = $this->input->post('user_id');
            $this->db->select('products.*,promotional_category.category,products.quantity as stock_quantity,products.id as product_id,promotional_category.id as category_id');
            $this->db->from('products');
            $this->db->join('promotional_category', 'promotional_category.id=products.promotional_category');
            $this->db->where('promotional_category.id', $category_id);
            $this->db->where('products.status', 1);
            if ($iosall == '') {
                $this->db->limit($limit, $start);
            }
            $results = $this->db->get()->result();
            $sale = $results;
            foreach ($sale as $x) {
                $device_id = $this->input->post('device_id');
                $cartQtys = 0;
                if ($user_id > 0) {
                    $cartQty = $this->basic_operation->uniqueSelect('carts', array('user_id' => $user_id, 'product_id' => $x->product_id));
                    if (!empty($cartQty)) {
                        $cartQtys = $cartQty[0]->quantity;
                    }
                } else {
                    $cartQty = $this->basic_operation->uniqueSelect('carts', array('device_id' => $device_id, 'product_id' => $x->product_id));
                    if (!empty($cartQty)) {
                        $cartQtys = $cartQty[0]->quantity;
                    }
                }
                $x->cart_product_quantity = "$cartQtys";
                if ($cartQtys > 0) {
                    $x->CartStatus = '1';
                } else {
                    $x->CartStatus = '0';
                }
                if ($user_id > 0) {
                    $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('user_id' => $user_id, 'product_id' => $x->product_id));
                } else {
                    $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('device_id' => $device_id, 'product_id' => $x->product_id));
                }
                if ($favCounter > 0) {
                    $x->favourite_status = "1";
                } else {
                    $x->favourite_status = "0";
                }
            }
            $collection = array(
                'error' => false,
                'message' => 'Request completed successfully',
                'data' => $sale,
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'category id & user id must be required',
            );
        }
        echo json_encode($collection);
    }

    public function getAllSubCategory($id)
    {
        $this->db->select('categories.*');
        $this->db->from('categories', 'categories.status=1');
        $this->db->where('categories.parent_category', $id);
        $results = $this->db->get()->result();
        $collection = array(
            'error' => false,
            'message' => 'Request completed successfully',
            'data' => $results,
        );
        echo json_encode($collection);
    }

    public function getProductById($id)
    {
        $this->db->select('products.*,categories.category,products.quantity as stock_quantity');
        $this->db->from('products', 'products.status=1');
        $this->db->join('categories', 'categories.id=products.category_id', 'inner');
        $this->db->where('products.id', $id);
        $results = $this->db->get()->result();
        foreach ($results as $x) {
            $device_id = $this->input->post('device_id');
            $cartQtys = 0;
            if ($user_id > 0) {
                $cartQty = $this->basic_operation->uniqueSelect('carts', array('user_id' => $user_id, 'product_id' => $x->product_id));
                if (!empty($cartQty)) {
                    $cartQtys = $cartQty[0]->quantity;
                }
            } else {
                $cartQty = $this->basic_operation->uniqueSelect('carts', array('device_id' => $device_id, 'product_id' => $x->product_id));
                if (!empty($cartQty)) {
                    $cartQtys = $cartQty[0]->quantity;
                }
            }
            $x->cart_product_quantity = "$cartQtys";
            if ($cartQtys > 0) {
                $x->CartStatus = '1';
            } else {
                $x->CartStatus = '0';
            }
            if ($user_id > 0) {
                $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('user_id' => $user_id, 'product_id' => $x->product_id));
            } else {
                $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('device_id' => $device_id, 'product_id' => $x->product_id));
            }
            if ($favCounter > 0) {
                $x->favourite_status = "1";
            } else {
                $x->favourite_status = "0";
            }
        }

        $collection = array(
            'error' => false,
            'message' => 'Request completed successfully',
            'data' => @$results[0],
        );
        echo json_encode($collection);
    }

    public function addressBook()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $device_id = $this->input->post('device_id');
            $form_data = array(
                'name'   => $this->input->post('name'),
                'address'   => $this->input->post('address'),
                'mobile'   => $this->input->post('mobile'),
                'user_id'   => $this->input->post('user_id'),
                'landmark'   => $this->input->post('landmark'),
                'device_id'   => $device_id
            );
            $this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('address', 'Address', 'required');
            $this->form_validation->set_rules('mobile', 'Mobile', 'required');
            $this->form_validation->set_rules('landmark', 'landmark', 'required');
            if ($this->form_validation->run() == FALSE) {
                $collection = array(
                    'error'    => true,
                    'name'  => form_error('name'),
                    'address'  => form_error('address'),
                    'mobile'  => form_error('mobile'),
                    'landmark' => form_error('landmark'),
                );
            } else {
                $user_id = $this->input->post('user_id');
                if ($user_id > 0) {
                    $count = $this->basic_operation->matchedRowCount('address_books', ['user_id' => $this->input->post('user_id'), 'default_address' => 1]);
                } else {
                    $count = $this->basic_operation->matchedRowCount('address_books', ['device_id' => $device_id, 'default_address' => 1]);
                }
                if ($count == 0) {
                    $form_data['default_address'] = '1';
                }
                if (!empty($this->input->post('address_id'))) {
                    if ($user_id > 0) {
                        $this->basic_operation->updateDetails('address_books', $form_data, array('id' => $this->input->post("address_id"), 'user_id' => $this->input->post("user_id")));
                    } else {
                        $this->basic_operation->updateDetails('address_books', $form_data, array('id' => $this->input->post("address_id"), 'device_id' => $device_id));
                    }
                    $collection = array(
                        'error' => false,
                        'message' => 'Address Updated successfully',
                        'data' => $form_data,
                    );
                } else {
                    $this->basic_operation->insertData('address_books', $form_data);
                    $collection = array(
                        'error' => false,
                        'message' => 'Address Added successfully',
                        'data' => $form_data,
                    );
                }
            }
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Only Post Method Allowed',
            );
        }
        echo json_encode($collection);
    }


    public function getAddressBook()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $device_id = $this->input->post('device_id');
            $user_id = $this->input->post('user_id');
            if ($user_id > 0) {
                $address = $this->Commonmodel->fetch_all_join("SELECT * FROM address_books WHERE user_id=$user_id ORDER BY id DESC");
            } else {

                $address = $this->Commonmodel->fetch_all_join("SELECT * FROM address_books WHERE device_id=$device_id ORDER BY id DESC");
            }

            $collection = array(
                'error' => false,
                'message' => 'Request completed successfully',
                'data' => $address,
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Only Post Method allowed',
            );
        }
        echo json_encode($collection);
    }


    public function deleteAddressBook()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $device_id = $this->input->post('device_id');

            $user_id = (int)$this->input->post('user_id');
            $address_id = (int)$this->input->post('address_id');
            if ($user_id > 0) {
                $this->basic_operation->DeleteData('address_books', array('user_id' => $user_id, 'id' => $address_id));
                $count = $this->basic_operation->matchedRowCount('address_books', array('user_id' => $user_id, 'default_address' => '1'));
            } else {
                $this->basic_operation->DeleteData('address_books', array('device_id' => $device_id, 'id' => $address_id));
                $count = $this->basic_operation->matchedRowCount('address_books', array('device_id' => $device_id, 'default_address' => '1'));
            }
            if ($count == '0') {
                $form_data = array('default_address' => '1');
                if ($user_id > 0) {
                    $user_address = $this->basic_operation->Uniqueselect('address_books', ['user_id' => $user_id], 1, false);
                } else {
                    $user_address = $this->basic_operation->Uniqueselect('address_books', ['device_id' => $device_id], 1, false);
                }
                $new_address_id = @$user_address[0]->id;
                $this->basic_operation->updateDetails('address_books', $form_data, array('id' => $new_address_id));
            }
            $collection = array(
                'error' => false,
                'message' => 'Address Delete successfully',
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Only Post Method With address_id Allowed',
            );
        }
        echo json_encode($collection);
    }


    public function AddToCart()
    {

        $this->form_validation->set_rules('product_id', 'product_id', 'required');
        $this->form_validation->set_rules('product_quantity', 'product quantity', 'required');
        $this->form_validation->set_rules('flag', 'flag', 'required');
        // $this->form_validation->set_rules('product_type', 'product_type', 'required');
        $this->form_validation->set_rules('user_id', 'User id', 'required');
        $this->form_validation->set_rules('device_id', 'device id', 'required');
        if ($this->form_validation->run() == FALSE) {
            $collection = array(
                'error'    => true,
                'product_id'  => form_error('product_id'),
                'quantity'  => form_error('product_quantity'),
                'flag'  => form_error('flag'),
                // 'product_type'  => form_error('product_type'),
                'user_id'  => form_error('user_id'),
                'device_id'  => form_error('device_id'),
            );
        } else {

            $product_id = $this->input->post('product_id');
            //   $product_type=$this->input->post('product_type');
            $flag = $this->input->post('flag');
            $product_quantity = (int)$this->input->post('product_quantity');
            $user_id = $this->input->post('user_id');
            $device_id = $this->input->post('device_id');

            $this->basic_operation->deleteData('carts', array('quantity <=' => 0));
            //   if($product_type==1)
            //   {
            $product = $this->basic_operation->Uniqueselect('products', array('id' => $product_id));
            //   }
            //   if($product_type==2)
            //   {
            //   $product=$this->basic_operation->Uniqueselect('offers',array('id'=>$product_id));
            //   }
            //   if($product_type==3)
            //   {
            //   $product=$this->basic_operation->Uniqueselect('promotional',array('id'=>$product_id));
            //   }
            if ($user_id > 0) {

                $product_stock_quantity = $product[0]->quantity;
                if (!$this->basic_operation->validateRowExist('carts', array('user_id' => $user_id, 'product_id' => $product_id)) === true) {
                    $rows = $this->basic_operation->Uniqueselect('carts', array('user_id' => $user_id, 'product_id' => $product_id));
                    $newCartProductQuantity = ($flag == 'plus') ? $rows[0]->quantity + $product_quantity : $rows[0]->quantity - $product_quantity;
                    $form_data = array(
                        'product_id'   => $product_id,
                        'product_type' => $product_type,
                        'stock_quantity'   => $product_stock_quantity,
                        'quantity'   => $newCartProductQuantity,
                        'user_id'   => $user_id,
                        'device_id' => $device_id
                    );
                    if ($product_stock_quantity > 0) {
                        $this->basic_operation->updateDetails('carts', $form_data, array('user_id' => $user_id, 'product_id' => $product_id));
                        $collection = array(
                            'error' => false,
                            'message' => 'Cart Updated successfully',
                        );
                    } else {
                        $collection = array(
                            'error' => true,
                            'message' => 'Out of Stocks',
                        );
                    }
                } else {
                    $newCartProductQuantity = $product_quantity;
                    if ($product_stock_quantity > 0) {
                        $form_data = array(
                            'product_id'   => $product_id,
                            // 'product_type'=>$product_type,
                            'stock_quantity'   => $product_stock_quantity,
                            'quantity'   => $newCartProductQuantity,
                            'user_id'   => $user_id,
                            'device_id' => $device_id
                        );
                        $this->basic_operation->insertData('carts', $form_data);
                        $collection = array(
                            'error' => false,
                            'message' => 'Added to Cart successfully',
                        );
                    } else {
                        $collection = array(
                            'error' => true,
                            'message' => 'Out Of Stocks',
                        );
                    }
                }
            } else {
                $product_stock_quantity = $product[0]->quantity;
                if (!$this->basic_operation->validateRowExist('carts', array('device_id' => $device_id, 'product_id' => $product_id)) === true) {
                    $rows = $this->basic_operation->Uniqueselect('carts', array('device_id' => $device_id, 'product_id' => $product_id));
                    $newCartProductQuantity = ($flag == 'plus') ? $rows[0]->quantity + $product_quantity : $rows[0]->quantity - $product_quantity;
                    $form_data = array(
                        'product_id'   => $product_id,
                        // 'product_type'=>$product_type,
                        'stock_quantity'   => $product_stock_quantity,
                        'quantity'   => $newCartProductQuantity,
                        'user_id'   => $user_id,
                        'device_id' => $device_id
                    );
                    if ($product_stock_quantity > 0) {
                        $this->basic_operation->updateDetails('carts', $form_data, array('device_id' => $device_id, 'product_id' => $product_id));
                        $collection = array(
                            'error' => false,
                            'message' => 'Cart Updated successfully',
                        );
                    } else {
                        $collection = array(
                            'error' => true,
                            'message' => 'Out of Stocks',
                        );
                    }
                } else {
                    $newCartProductQuantity = $product_quantity;
                    if ($product_stock_quantity > 0) {
                        $form_data = array(
                            'product_id'   => $product_id,
                            // 'product_type'=>$product_type,
                            'stock_quantity'   => $product_stock_quantity,
                            'quantity'   => $newCartProductQuantity,
                            'user_id'   => $user_id,
                            'device_id' => $device_id
                        );
                        $this->basic_operation->insertData('carts', $form_data);
                        $collection = array(
                            'error' => false,
                            'message' => 'Added to Cart successfully',
                        );
                    } else {
                        $collection = array(
                            'error' => true,
                            'message' => 'Out Of Stocks',
                        );
                    }
                }
            }
        }
        echo json_encode($collection);
    }

    public function myCart()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $user_id = $this->input->post('user_id');
            $this->basic_operation->deleteData('carts', array('quantity <=' => 0));
            $device_id = $this->input->post('device_id');

            if ($user_id > 0) {

                $this->db->select('carts.*,carts.id as cart_id,carts.user_id as cart_user_id,carts.quantity as cart_product_quantity, products.*,products.id as product_id,products.quantity as productsQuantity');
                $this->db->from('carts');
                $this->db->join('products', 'products.id = carts.product_id');
                $this->db->where(['carts.user_id' => $user_id]);
                $this->db->where('products.status', 1);
                $Cart1 = $this->db->get()->result();

                // $this->db->select('carts.*,carts.id as cart_id,carts.user_id as cart_user_id,carts.quantity as cart_product_quantity, offers.*,offers.id as product_id,offers.quantity as productsQuantity');
                // $this->db->from('carts');
                // $this->db->join('offers', 'offers.id = carts.product_id');
                // $this->db->where(['carts.user_id'=>$user_id,'carts.product_type'=>2]);
                // $Cart2=$this->db->get()->result();

                // $this->db->select('carts.*,carts.id as cart_id,carts.user_id as cart_user_id,carts.quantity as cart_product_quantity, promotional.*,promotional.id as product_id,promotional.quantity as productsQuantity');
                // $this->db->from('carts');
                // $this->db->join('promotional', 'promotional.id = carts.product_id');
                // $this->db->where(['carts.user_id'=>$user_id,'carts.product_type'=>3]);
                // $Cart3=$this->db->get()->result();
            } else {
                $this->db->select('carts.*,carts.id as cart_id,carts.user_id as cart_user_id,carts.quantity as cart_product_quantity, products.*,products.id as product_id,products.quantity as productsQuantity');
                $this->db->from('carts');
                $this->db->join('products', 'products.id = carts.product_id');
                $this->db->where(['carts.device_id' => $device_id,]);
                $this->db->where('products.status', 1);
                $Cart1 = $this->db->get()->result();

                // $this->db->select('carts.*,carts.id as cart_id,carts.user_id as cart_user_id,carts.quantity as cart_product_quantity, offers.*,offers.id as product_id,offers.quantity as productsQuantity');
                // $this->db->from('carts');
                // $this->db->join('offers', 'offers.id = carts.product_id');
                // $this->db->where(['carts.device_id'=>$device_id,'carts.product_type'=>2]);
                // $Cart2=$this->db->get()->result();

                // $this->db->select('carts.*,carts.id as cart_id,carts.user_id as cart_user_id,carts.quantity as cart_product_quantity, promotional.*,promotional.id as product_id,promotional.quantity as productsQuantity');
                // $this->db->from('carts');
                // $this->db->join('promotional', 'promotional.id = carts.product_id');
                // $this->db->where(['carts.device_id'=>$device_id,'carts.product_type'=>3]);
                // $Cart3=$this->db->get()->result(); 
            }
            // $data=array_merge($Cart1,$Cart2,$Cart3);
            $data = $Cart1;
            foreach ($data as $x) {

                $device_id = $this->input->post('device_id');
                $cartQtys = 0;

                if ($user_id > 0) {
                    $cartQty = $this->basic_operation->uniqueSelect('carts', array('user_id' => $user_id, 'product_id' => $x->product_id));
                    if (!empty($cartQty)) {
                        $cartQtys = $cartQty[0]->quantity;
                    }
                } else {
                    $cartQty = $this->basic_operation->uniqueSelect('carts', array('device_id' => $device_id, 'product_id' => $x->product_id));
                    if (!empty($cartQty)) {
                        $cartQtys = $cartQty[0]->quantity;
                    }
                }
                $x->cart_product_quantity = "$cartQtys";
                if ($cartQtys > 0) {
                    $x->CartStatus = '1';
                } else {
                    $x->CartStatus = '0';
                }
                if ($user_id > 0) {
                    $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('user_id' => $user_id, 'product_id' => $x->product_id));
                } else {
                    $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('device_id' => $device_id, 'product_id' => $x->product_id));
                }
                if ($favCounter > 0) {
                    $x->favourite_status = "1";
                } else {
                    $x->favourite_status = "0";
                }
            }
            $collection = array(
                'error' => false,
                'message' => 'Request completed successfully',
                'data' => $data,
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Only Post Method Allowed',
            );
        }
        echo json_encode($collection);
    }

    public function DeleteCartProduct()
    {
        $this->form_validation->set_rules('cart_id', 'cart_id', 'required');
        $this->form_validation->set_rules('user_id', 'User Id', 'required');
        if ($this->form_validation->run() == FALSE) {
            $collection = array(
                'error'    => true,
                'cart_id'  => form_error('cart_id'),
                'user_id'  => form_error('user_id'),
            );
        } else {
            $device_id = $this->input->post('device_id');

            $cart_id = $this->input->post('cart_id');
            $user_id = $this->input->post('user_id');
            if ($user_id > 0) {
                $this->basic_operation->deleteData('carts', array('user_id' => $user_id, 'id' => $cart_id));
            } else {
                $this->basic_operation->deleteData('carts', array('device_id' => $device_id, 'id' => $cart_id));
            }
            $collection = array(
                'error' => false,
                'message' => 'Deleted from Cart successfully',
            );
        }
        echo json_encode($collection);
    }

    public function addMyWishList()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST' && $this->input->post('product_id') &&  $this->input->post('wishlist_id') == '0') {
            $user_id = $this->input->post('user_id');
            $device_id = $this->input->post('device_id');

            // $product_type=$this->input->post('product_type');
            $product_id = $this->input->post('product_id');
            $wishlist_id = $this->input->post('wishlist_id');
            if ($user_id > 0) {
                $this->basic_operation->deleteData('wishlists', array('user_id' => $user_id, 'product_id' => $product_id));
            } else {
                $this->basic_operation->deleteData('wishlists', array('device_id' => $device_id, 'product_id' => $product_id));
            }
            $collection = array(
                'error' => false,
                'message' => 'Deleted From Wishlist Successfully',
            );
        } elseif ($this->input->server('REQUEST_METHOD') == 'POST' && $this->input->post('product_id')) {
            $product_id = $this->input->post('product_id');
            $user_id = $this->input->post('user_id');
            //  $product_type=$this->input->post('product_type');
            $device_id = $this->input->post('device_id');

            if ($user_id > 0) {
                if ($this->basic_operation->validateRowExist('wishlists', array('user_id' => $user_id, 'product_id' => $product_id)) === true) {
                    $form_data = array(
                        'product_id'   => $product_id,
                        'user_id'   => $user_id,
                        // 'product_type'=>$product_type,
                        'device_id' => $device_id
                    );
                    $this->basic_operation->insertData('wishlists', $form_data);
                    $collection = array(
                        'error' => false,
                        'message' => 'Added To Wishlist Successfully',
                    );
                } else {
                    $collection = array(
                        'error' => false,
                        'message' => 'Already Added To Wishlist Successfully',
                    );
                }
            } else {
                if ($this->basic_operation->validateRowExist('wishlists', array('device_id' => $device_id, 'product_id' => $product_id)) === true) {
                    $form_data = array(
                        'product_id'   => $product_id,
                        'user_id'   => $user_id,
                        // 'product_type'=>$product_type,
                        'device_id' => $device_id
                    );
                    $this->basic_operation->insertData('wishlists', $form_data);
                    $collection = array(
                        'error' => false,
                        'message' => 'Added To Wishlist Successfully',
                    );
                } else {
                    $collection = array(
                        'error' => false,
                        'message' => 'Already Added To Wishlist Successfully',
                    );
                }
            }
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Product id and must be required',
            );
        }
        echo json_encode($collection);
    }

    public function myWishList()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $limit = 10;
            (int)$start = $this->input->post('page') ? $this->input->post('page') : 0;
            $start *= $limit;
            $iosall = $this->input->post('iosall');
            $user_id = $this->input->post('user_id');
            $device_id = $this->input->post('device_id');

            $this->db->select('wishlists.*,products.*,products.name as product_name,wishlists.id as wishlist_id');
            $this->db->from('wishlists');
            $this->db->join('products', 'products.id = wishlists.product_id');
            if ($user_id > 0) {
                $this->db->where(['wishlists.user_id' => $user_id]);
            } else {
                $this->db->where(['wishlists.device_id' => $device_id]);
            }
            $this->db->where('products.status', 1);
            if ($iosall == '') {
                $this->db->limit($limit, $start);
            }
            // $this->db->order_by('wishlists.id','desc');
            $data1 = $this->db->get()->result();

            // $this->db->select('wishlists.*,promotional.*,promotional.name as product_name,wishlists.id as wishlist_id');
            // $this->db->from('wishlists');
            // $this->db->join('promotional', 'promotional.id = wishlists.product_id');
            // if($user_id > 0){
            //     $this->db->where(['wishlists.user_id'=> $user_id,'wishlists.product_type'=>'3']);
            // }else{
            //     $this->db->where(['wishlists.device_id'=> $device_id,'wishlists.product_type'=>'3']);  
            // }
            //   $this->db->where('promotional.status',1);
            // $this->db->limit($limit,$start);
            // $data2=$this->db->get()->result(); 

            // $this->db->select('wishlists.*,offers.*,offers.name as product_name,wishlists.id as wishlist_id');
            // $this->db->from('wishlists');
            // $this->db->join('offers', 'offers.id = wishlists.product_id');
            // if($user_id > 0){
            //     $this->db->where(['wishlists.user_id'=> $user_id,'wishlists.product_type'=>'2']);
            // }else{
            //     $this->db->where(['wishlists.device_id'=> $device_id,'wishlists.product_type'=>'2']);  
            // }
            // $this->db->where('offers.status',1);
            // $this->db->limit($limit,$start);

            // $data3= $this->db->get()->result();
            $totalWishlist = $data1;

            foreach ($totalWishlist as $x) {
                $device_id = $this->input->post('device_id');
                $cartQtys = 0;
                if ($user_id > 0) {
                    $cartQty = $this->basic_operation->uniqueSelect('carts', array('user_id' => $user_id, 'product_id' => $x->product_id));
                    if (!empty($cartQty)) {
                        $cartQtys = $cartQty[0]->quantity;
                    }
                } else {
                    $cartQty = $this->basic_operation->uniqueSelect('carts', array('device_id' => $device_id, 'product_id' => $x->product_id));
                    if (!empty($cartQty)) {
                        $cartQtys = $cartQty[0]->quantity;
                    }
                }
                $x->cart_product_quantity = "$cartQtys";
                if ($cartQtys > 0) {
                    $x->CartStatus = '1';
                } else {
                    $x->CartStatus = '0';
                }
                if ($user_id > 0) {
                    $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('user_id' => $user_id, 'product_id' => $x->product_id));
                } else {
                    $favCounter = $this->basic_operation->matchedRowCount('wishlists', array('device_id' => $device_id, 'product_id' => $x->product_id));
                }
                if ($favCounter > 0) {
                    $x->favourite_status = "1";
                } else {
                    $x->favourite_status = "0";
                }
            }
            $collection = array(
                'error' => false,
                'message' => 'Request Completed Successfully',
                'wishlist' => $totalWishlist
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Post method must be required',
            );
        }
        echo json_encode($collection);
    }

    public function deleteWishList()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST' && $this->input->post('user_id') && $this->input->post('product_id')) {
            $user_id = $this->input->post('user_id');
            $product_id = $this->input->post('product_id');
            // $product_type=$this->input->post('product_type');
            $this->basic_operation->deleteData('wishlists', array('user_id' => $user_id, 'product_id' => $product_id));
            $collection = array(
                'error' => false,
                'message' => 'Deleted From Wishlist Successfully',
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Product id and User id must be required',
            );
        }
        echo json_encode($collection);
    }

    public function myBooking()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST' && $this->input->post('user_id')) {
            $limit = 10;
            $start = $this->input->post('page');
            $start *= $limit;
            $iosall = $this->input->post('iosall');
            @$user_id = $this->input->post('user_id');
            $this->db->select('bookings.*,SUM(bookings.price) as TotalPrice');
            $this->db->from('bookings');
            $this->db->where(array('bookings.user_id' => $user_id, 'bookings.status <' => 3));
            $this->db->group_by(array("bookings.user_id", "bookings.order_id"));
            $this->db->order_by('bookings.id', 'desc');
            if ($iosall == '') {
                $this->db->limit($limit, $start);
            }
            $data = $this->db->get()->result();

            foreach ($data as $x) {
                $order_id = $x->order_id;
                $myBookingProduct = $this->basic_operation->matchedRowCount('bookings', array('order_id' => $order_id));
                $x->TotalProductsQty = "$myBookingProduct";
                $x->booking_date = date("F j, Y", strtotime($x->booking_date));
            }
            $this->db->select('bookings.*,SUM(bookings.price) as TotalPrice');
            $this->db->from('bookings');
            $this->db->where(array('bookings.user_id' => $user_id, 'bookings.status =' => 3));
            $this->db->group_by(array("bookings.user_id", "bookings.order_id"));
            $this->db->order_by('bookings.id', 'desc');
            $data2 = $this->db->get()->result();

            foreach ($data2 as $item) {
                $order_id = $item->order_id;
                $myBookingProduct = $this->basic_operation->matchedRowCount('bookings', array('order_id' => $order_id));
                $item->TotalProductsQty = "$myBookingProduct";
                $item->booking_date = date("F j, Y", strtotime($item->booking_date));
                // if($item->coupon_id==null){
                //     $item->coupon_id=0;
                //     $item->coupon_code='';
                //     $item->coupon_title='';
                //     $item->discount_percentage=0;
                // }
                // if($item->address_id==0){
                //     $item->address=$item->web_address;
                //     $item->landmark=$item->web_landmark;
                //     $item->mobile=$item->web_mobile;
                //     $item->name=$item->web_name;
                // }

            }

            $collection = array(
                'error' => false,
                'message' => 'Request Completed Successfully',
                'cancelled' => $data2,
                'normal' => $data
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'User id must be required',
            );
        }
        echo json_encode($collection);
    }

    public function getBookingDetails()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST' && $this->input->post('user_id') && $this->input->post('order_id')) {
            $user_id = $this->input->post('user_id');
            $booking_id = $this->input->post('order_id');
            $this->db->select('bookings.*,');
            $this->db->from('bookings');
            $this->db->where(array('bookings.user_id' => $user_id, 'bookings.order_id' => $booking_id));
            $data = $this->db->get()->result();

            // foreach($data as $item){
            //     if($item->coupon_id==null){
            //         $item->coupon_id=0;
            //         $item->coupon_code='';
            //         $item->coupon_title='';
            //         $item->discount_percentage=0;
            //     }
            //     if($item->address_id==0){
            //         $item->address=$item->web_address;
            //         $item->landmark=$item->web_landmark;
            //         $item->mobile=$item->web_mobile;
            //         $item->name=$item->web_name;
            //     }
            // }

            $collection = array(
                'error' => false,
                'message' => 'Request Completed Successfully',
                'data' => $data
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'User id and Order id must be required',
            );
        }
        echo json_encode($collection);
    }





    public function getMessages()
    {
        $msgs = $this->basic_operation->uniqueSelect('cancel_msgs', array('status' => 1));
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $msgs
        );
        echo json_encode($collection);
    }



    public function Profile()
    {
        $user_id = $this->input->post('email');
        $this->AdminDetails->fetchSingleById("mst_user", $user_id, 'email');
        $collection = array(
            'error' => false,
            'message' => 'Profile Updated Successfully...'
        );
        echo json_encode($collection);
    }
    public function updateProfile()
    {
        $user_id = $this->input->post('user_id');
        $name = $this->input->post('name');
        $address = $this->input->post('address');
        $mobile = $this->input->post('mobile');

        $this->basic_operation->updateDetails('mst_user', array('username' => $name, 'phone' => $mobile, 'address' => $address), array('id' => $user_id));
     
        $collection = array(
            'error' => false,
            'message' => 'Profile Updated Successfully...'
        );
        echo json_encode($collection);
    }
    public function changePassword()
    {

        $current_password = md5($this->input->post('password'));
        $new_password = md5($this->input->post('new_password'));
        $confirm_password = md5($this->input->post('confirm_password'));
        $user_id = $this->input->post('id');
        $user_data = $this->basic_operation->Uniqueselect('mst_user', array('id' => $user_id));

        $check = $this->AdminDetails->fetchCol_Con("mst_user", "id", "id='$user_id' and pass='$current_password'");

        if (empty($check[0]->id)) {
            $collection = array(
                'error' => true,
                'message' => 'Current Password is Invalid'
            );
            echo json_encode($collection);
            exit;
        }
        if (!empty($current_password) && !empty($new_password) && !empty($confirm_password)) {
            if ($this->input->post('confirm_password') != $this->input->post('new_password')) {
                $collection = array(
                    'error' => true,
                    'message' => 'New Password is not Matched With Confirm Password'
                );
            } else {
                $this->basic_operation->updateDetails('mst_user', array('pass' => $new_password), array('id' => $user_id));
                $collection = array(
                    'error' => false,
                    'message' => 'Password Updated Successfully...'
                );
            }
        }
        echo json_encode($collection);
    }
    

    public function getFreeVideos()
    {
        $results = $this->AdminDetails->fetchSingleById('free_videos_tb', "1", 'status');
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function getVacancy()
    {
        $results = $this->AdminDetails->fetchSingleById('mst_vacancy', "1", 'status');
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function getBooks()
    {
        $results = $this->AdminDetails->fetchSingleById('book_tb', "1", 'status');
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function getMypurchase($id)
    {
        $query = $this->db->select('video_subject_tb.*,payment_course_tb.uid,payment_course_tb.pay_status')
            ->from('video_subject_tb')
            ->join('payment_course_tb', 'payment_course_tb.courseid = video_subject_tb.id', 'left')
            ->where('uid', $id)
            ->where('pay_status', 'Credit')
            ->group_by('courseid')
            ->order_by('id', 'DESC');
        $query = $this->db->get();
        $results = $query->result();

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function getSubject($id)
    {
        $results = $this->AdminDetails->fetchColCon("video_subject_cat_tb", "*", "category=$id and status=1");
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function payment($cid, $uid)
    {
        $course = $this->AdminDetails->fetchSingle("video_subject_tb", $cid);
        $rs = $this->AdminDetails->fetchSingle("mst_user", $uid);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.instamojo.com/api/1.1/payment-requests/');
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt(
            $ch,
            CURLOPT_HTTPHEADER,
            array(
                "X-Api-Key:17f4acbd4c1b096c75243b73159a2609",
                "X-Auth-Token:6932e56d2be7b286a27599b6299a8a4d"
            )
        );
        $payload = array(
            'purpose' => $course[0]->sub_name,
            'amount' => $course[0]->price,
            'phone' => $rs[0]->phone,
            'buyer_name' => $rs[0]->username,
            'redirect_url' => 'https://www.careerfoundation.org.in/home/success/' . $cid . '/' . $uid,
            'send_email' => true,
            'webhook' => 'https://www.careerfoundation.org.in/home/webhook/',
            'send_sms' => true,
            'email' => $rs[0]->email,
            'allow_repeated_payments' => false
        );

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
        $response = curl_exec($ch);
        curl_close($ch);
        //echo $response;
        $json_decode = json_decode($response, true);
        $data = array(
            'transactionid' => $json_decode['payment_request']['id'],
            'phone' => $json_decode['payment_request']['phone'],
            'email' => $json_decode['payment_request']['email'],
            'buyer_name' => $json_decode['payment_request']['buyer_name'],
            'amount' => $json_decode['payment_request']['amount'],
            'purpose' => $json_decode['payment_request']['purpose'],
            'pay_status' => $json_decode['payment_request']['status'],
            'courseid' => $cid,
            'uid' => $uid,
        );

        $insert = $this->AdminDetails->insertData("payment_course_tb", $data);
        $long_url = $json_decode['payment_request']['longurl'];
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $long_url
        );
        echo json_encode($collection);
    }
    public function getSubjectVideo($cid, $sid)
    {

        $query = $this->db->query("select * from webiste_videos_tb where category='$cid' and subject_category='$sid' and status='1'");
        $results = $query->result();

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function getSubjectVideoNew($cid, $sid, $type)
    {
        if ($type == 'video') {
            $query = $this->db->query("select id,category,title,videos,description from webiste_videos_tb where category='$cid' and subject_category='$sid' and status='1' and videos IS NOT NULL AND videos !=''");
        } else {
            $query = $this->db->query("select id,category,title,pdfs,description from webiste_videos_tb where category='$cid' and subject_category='$sid' and status='1' and pdfs IS NOT NULL AND pdfs!=''");
        }


        $results = $query->result();

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function thankyou($cid, $uid)
    {
        $data = array(
            'pay_status' => 'Credit',
        );
        $this->db->where("uid", $uid);
        $this->db->where("courseid", $cid);
        $query = $this->db->update("payment_course_tb", $data);
        $results = 'Updated successfully';
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function categories()
    {
        $results = $this->AdminDetails->fetchCol_Con('course_menu_tb', "course_name,courses,images,description,video,id", "status=1 order by position asc");
        $collection = array(
            'error' => false,
            'message' => 'Request completed successfully',
            'data' => $results,
        );
        echo json_encode($collection);
    }
    public function courses($cid, $userId)
    {

        $data = [];
        $results = $this->AdminDetails->fetchCol_Con("course_menu_tb", "courses,course_name,id", "id=$cid and status='1'");
        $course_id = explode(",", $results[0]->courses);
        $all_courses = array();
        for ($i = 0; $i < count($course_id); $i++) {
            $course = $this->AdminDetails->fetchCon("video_subject_tb", "id=$course_id[$i] order by position ASC");
            array_push($all_courses, $course[0]);
        }
        //sorting
        function toLowerCase($a)
        {
            return strtolower($a);
        }
        $sortArray = array_map("toLowerCase", array_column($all_courses, 'position'));
        array_multisort($sortArray, SORT_ASC, $all_courses);
        foreach ($all_courses as $runs) {
            $checkPayment = $this->AdminDetails->fetchCol_Con("payment_course_tb", "id,pay_status", "uid=$userId and courseid=$runs->id and pay_status='Credit'");

            $datas = array(
                "id" => $runs->id,
                "sub_name" => $runs->sub_name,
                "mrp" => $runs->mrp,
                "price" => $runs->price,
                "imagealt" => $runs->imagealt,
                "images" => $runs->images,
                "pdf" => $runs->pdf,
                "description" => $runs->description,
                "video" => $runs->video,
                "full_video" => $runs->full_video,
                "type" => $runs->type,
                "course_type" => $runs->course_type,
                "cdate" => $runs->cdate,
                "status" => $runs->status,
                "position" => $runs->position,
                "trending" => $runs->trending,
                "purchased" => $checkPayment[0]->pay_status
            );
            array_push($data, $datas);
        }
        //endsorting
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $data,

        );
        echo json_encode($collection);
    }

    public function levelbycourse($subcat)
    {
        $results = $this->AdminDetails->fetchCol_Con("subject_category_tb", "id,category as title,mrp,price,imagealt,images,pdf,description", "subject=$subcat and status='1'");
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results,
        );
        echo json_encode($collection);
    }
    public function SubjectVideosWithCat($cid, $sid, $subcat)
    {

        $query = $this->db->query("select * from webiste_videos_tb where category='$cid' and subject_category='$sid' and subcategory='$subcat' and status='1'");
        $results = $query->result();

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function subjectfolder($subcat)
    {

        $query = $this->db->query("select * from video_category_tb where  subcategory='$subcat'  and status='1'");
        $results = $query->result();
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function subjectbylevel($subjectid)
    {

        $query = $this->db->query("select id,course,subject,category as subname,mrp,price,imagealt,images,pdf,description,type,cdate,status from subject_category_tb where subject='$subjectid' and status='1'");
        $results = $query->result();

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function videosbysubjectfolder($id)
    {

        $query = $this->db->query("select * from webiste_videos_tb where subcategory='$id' and status='1'");
        $results = $query->result();

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function videos($id)
    {

        $query = $this->db->query("select * from webiste_videos_tb where video_categories='$id' and status='1'");
        $results = $query->result();

        $collection = array(
            'error' => false,
            'message' => 'Request  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function coursesbycategory($id)
    {

        $all_result = array();
        $results = $this->AdminDetails->fetchSingleById('video_subject_cat_tb', "$id", 'category');
        foreach ($results as $run) {
            $subjectid = $run->id;
            $courseid = $run->category;
            $demo = $this->AdminDetails->fetchCol_Con("free_videos_tb", "videos,full_video", "category='$courseid' and subject_category='$subjectid'");
            // print_r($run);
            // print_r($demo[0]);
            $obj_merged = (object) array_merge(
                (array) $run,
                (array) $demo[0]
            );
            //  print_r($obj_merged);
            array_push($all_result, $obj_merged);
        }

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $all_result
        );
        echo json_encode($collection);
    }


    public function checkdeviceId($userid, $deviceId)
    {
        $query = $this->db->query("select * from mst_user where id='$userid' and deviceId='$deviceId'");
        $results = $query->result();
        if ($results[0]->id != '') {
            $collection = array(
                'error' => false,
                'status' => 200,
                'message' => 'Request  Completed Successfully',
                'data' => $results
            );
            echo json_encode($collection);
        } else {


            $collection = array(

                'status' => 403,
                'error' => true,
                'message' => 'Error occured',
            );
            echo json_encode($collection);
        }
    }

    public function homepage()
    {
        $query = $this->db->query("select * from advertisement_tb order by position asc");
        $results = $query->result();
        if ($results[0]->id != '') {
            $collection = array(
                'error' => false,
                'status' => 200,
                'message' => 'Request  Completed Successfully',
                'data' => $results
            );
            echo json_encode($collection);
        } else {

            $collection = array(
                'error' => true,
                'message' => 'Error occured',
            );
            echo json_encode($collection);
        }
    }

    public function livestream($id)
    {
        $data = [];
        $query = $this->db->query("select v.id,v.title,v.videos,v.freeOrPaid,v.category,c.sub_name as courseName,v.liveDate from webiste_videos_tb  as v LEFT JOIN video_subject_tb as c ON c.id=v.category where v.live='1'");

        $results = $query->result();
        foreach ($results as $run) {
            $checkPayment = $this->AdminDetails->fetchCol_Con("payment_course_tb", "id", "courseid=$run->category  and pay_status='Credit' and uid=$id");
            $paid = $checkPayment[0]->id > 0 ? 1 : 0;
            if($paid || $run->freeOrPaid==0){
                $datas = array(
                "id" => $run->id,
                "courseName" => $run->courseName,
                "title" => $run->title,
                "videos" => $run->videos,
                "freeOrPaid" => $run->freeOrPaid,
                "category" => $run->category,
                "paid" => $paid,
                "liveDate"=>date('d-m-Y h:i:s A',strtotime($run->liveDate)),
            );
            array_push($data, $datas); 
            }
           
        }
        if ($results[0]->id != '') {
            $collection = array(
                'error' => false,
                'status' => 200,
                'message' => 'Request  Completed Successfully',
                'data' => $data
            );
            echo json_encode($collection);
        } else {


            $collection = array(
                'error' => true,
                'message' => 'Error occured',
            );
            echo json_encode($collection);
        }
    }
    public function aboutus()
    {
        $query = $this->db->query("select id,Title_Id,Des_Id from about_tb");
        $results = $query->result();
        if ($results[0]->id != '') {
            $collection = array(
                'error' => false,
                'status' => 200,
                'message' => 'Request  Completed Successfully',
                'data' => $results
            );
            echo json_encode($collection);
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Error occured',
            );
            echo json_encode($collection);
        }
    }
    //check payment failed or success
    public function razorpay()
    {
          $razorpay_payment_id = trim($this->input->post('razorpay_payment_id'));
        $amount = trim($this->input->post('amount'));
        $data = array(
            'amount' => trim($this->input->post('amount')),
            'courseid' => trim($this->input->post('courseid')),
            'email' => trim($this->input->post('email')),
            'phone' => trim($this->input->post('mobile')),
            'buyer_name' => trim($this->input->post('name')),
            'pay_status' => trim($this->input->post('pay_status')),
            'purpose' => trim($this->input->post('purpose')),
            'transactionid' => trim($this->input->post('razorpay_payment_id')),
            'uid' => trim($this->input->post('uid')),
            'coursePrice'=>trim($this->input->post('coursePrice')),
             'couponCode'=>trim($this->input->post('couponCode')),
             'discount'=>trim($this->input->post('discount')),

        );
        $insert = $this->AdminDetails->insertData("payment_course_tb", $data);

        if ($insert) {
             $ch = $this->capturePayment($razorpay_payment_id, $amount);
            $collection = array(
                'error' => false,
                'message' => 'Payment successful...'
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Some error occured.Try again...'
            );
        }

        echo json_encode($collection);
    }
    public function sendmessage()
    {
        $data = array(
            'chat_user_id' => trim($this->input->post('chat_user_id')),
            'chat_connection_id' => trim($this->input->post('chat_connection_id')),
            'message' => trim($this->input->post('message')),

        );
        $insert = $this->AdminDetails->insertData("chat_messages", $data);

        if ($insert) {
            $collection = array(
                'error' => false,
                'message' => 'Message send successfully...'
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Some error occured.Try again...'
            );
        }

        echo json_encode($collection);
    }
    public function chatGroupMessage($id)
    {

        $query = $this->db->query("select g.id,g.message,g.chat_user_id,g.is_read,g.created_at,u.username from group_messages as g
            LEFT JOIN mst_user as u ON u.id=g.chat_user_id
         where g.discussionGroupId='$id' order by g.id desc limit 50");
        $results = $query->result();

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function sendGroupMessage()
    {

        $arr = array(trim($this->input->post('chat_user_id')));
        $is_read = implode(" ", $arr);
        $data = array(
            'chat_user_id' => trim($this->input->post('chat_user_id')),
            'discussionGroupId' => trim($this->input->post('chat_connection_id')),
            'message' => trim($this->input->post('message')),
            'is_read' => $is_read,
            'created_at' => date('Y-m-d H:i:s')

        );
        $insert = $this->AdminDetails->insertData("group_messages", $data);

        if ($insert) {
            $insert_id = $this->db->insert_id();
            $query = $this->db->query("select * from group_messages where id=$insert_id");
            $results = $query->result();

            $collection = array(
                'error' => false,
                'message' => 'Message send successfully...',
                'data' => $results
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Some error occured.Try again...'
            );
        }

        echo json_encode($collection);
    }

    public function lastGroupMessage($groupId, $id)
    {

        $query = $this->db->query("select g.id,g.message,g.chat_user_id,g.is_read,g.created_at,u.username from group_messages as g
            LEFT JOIN mst_user as u ON u.id=g.chat_user_id
         where g.discussionGroupId ='$groupId' and NOT find_in_set($id,is_read) order by id ASC");
        $results = $query->result();
        foreach ($results as $run) {
            $uid = $run->id;
            $is_read = $run->is_read . ',' . $id;
            $is_read;
            $update = $this->db->query("update group_messages set is_read='$is_read' where id=$uid");
        }
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }

    //send live stream message
    public function chatLiveStreamMessage($id)
    {

        $query = $this->db->query("select l.id,l.message,l.chat_user_id,l.is_read,l.created_at,u.username from live_stream_messages as l
            LEFT JOIN mst_user as u ON u.id=l.chat_user_id
         where l.video='$id' order by l.id desc limit 100");
        $results = $query->result();

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function sendLiveStreamMessage()
    {

        $arr = array(trim($this->input->post('chat_user_id')));
        $is_read = implode(" ", $arr);
        $data = array(
            'chat_user_id' => trim($this->input->post('chat_user_id')),
            'video' => trim($this->input->post('chat_connection_id')),
            'message' => trim($this->input->post('message')),
            'is_read' => $is_read,
            'created_at' => date('Y-m-d H:i:s')


        );
        $insert = $this->AdminDetails->insertData("live_stream_messages", $data);

        if ($insert) {
            $collection = array(
                'error' => false,
                'message' => 'Message send successfully...'
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Some error occured.Try again...'
            );
        }

        echo json_encode($collection);
    }

    public function lastLiveStreamMessage($groupId, $id)
    {

        $query = $this->db->query("select l.id,l.message,l.chat_user_id,l.is_read,l.created_at,u.username from live_stream_messages as l
            LEFT JOIN mst_user as u ON u.id=l.chat_user_id
         where l.video ='$groupId' and NOT find_in_set($id,is_read) order by id ASC");
        $results = $query->result();
        foreach ($results as $run) {
            $uid = $run->id;
            $is_read = $run->is_read . ',' . $id;
            $is_read;
            $update = $this->db->query("update live_stream_messages set is_read='$is_read' where id=$uid");
        }
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    //end live stream message
    public function demovideos($cid)
    {
        $results = $this->AdminDetails->fetchCol_Con("free_videos_tb", "id,title,videos,pdfs,thumbnail,description", "category=$cid and status='1'");

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }

    public function teachers()
    {
        $results = $this->AdminDetails->fetchCol_Con("teacher_tb", "id,name,image,designation,email", "is_deleted='0' and status='1'");

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function connection()
    {

        $this->load->library('curl');
        $sid  = $this->input->post('sid');
        $tid   = $this->input->post('tid');
        $form_data = array(
            'student_id'  => $sid,
            'teacher_id'   => $tid,

        );

        $checkConnection = $this->AdminDetails->fetchCol_Con("connection_tb", "id", "teacher_id=$tid and student_id=$sid");

        if ($checkConnection[0]->id) {
            $array = array(
                'status' => '200',
                'connectionId' => $checkConnection[0]->id,
                'error'    => false,
                'message' => 'Already connected.'
            );
        } else {
            $createConnection = $this->AdminDetails->insertData("connection_tb", $form_data);
            $checkConnection = $this->AdminDetails->fetchCol_Con("connection_tb", "id", "teacher_id=$tid and student_id=$sid");

            if ($createConnection) {
                $array = array(
                    'status' => '200',
                    'connectionId' => $checkConnection[0]->id,
                    'error'    => false,
                    'message' => 'Connected.'
                );
            } else {
                $array = array(
                    'status' => '403',
                    'error'    => true,
                    'message' => 'Some error occured.'
                );
            }
        }

        echo json_encode($array, true);
    }


    public function demosubject()
    {
        $results = $this->AdminDetails->fetchCol_Con("video_subject_tb", "id,sub_name,images,price,description,mrp,price,video", "status='1' AND course_type='free' order by id desc");

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function demoSubjectCategory($id)
    {
        $results = $this->AdminDetails->fetchCol_Con("video_subject_cat_tb", "id,subname,images,price,description,mrp,price", "status='1' and category=$id AND subject_type='free'");

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function getFreeVideosBySubject($subjectCatId)
    {
        $results = $this->AdminDetails->fetchCol_Con('free_videos_tb', 'id,title,videos,pdfs,thumbnail,description', "status=1 and subject_category=$subjectCatId");
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function checkdiscount($uid, $new_course_id)
    {
        $results = $this->AdminDetails->fetchCol_Con('course_discounts_for_old_students', 'id,old_course_id,discount', "status=1 and new_course_id=$new_course_id");
        $oldCourse_id = $results[0]->old_course_id;
        if ($oldCourse_id != '') {

            $discountAvailable = $this->AdminDetails->fetchCol_Con('payment_course_tb', 'id', "uid=$uid and pay_status='Credit' and courseid=$oldCourse_id");

            if ($discountAvailable[0]->id != '') {
                $data = array(
                    'discount' => $results[0]->discount
                );
            }
        } else {
            $data = array(
                'discount' => 0
            );
        }
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $data
        );
        echo json_encode($collection);
    }
    public function demovideosnew($cid, $type)
    {
        if ($type == 'video') {
            $results = $this->AdminDetails->fetchCol_Con("free_videos_tb", "id,title,videos,description", "category=$cid and status='1' and videos IS NOT NULL AND videos !=''");
        } else {
            $results = $this->AdminDetails->fetchCol_Con("free_videos_tb", "id,title,pdfs,description", "category=$cid and status='1' and pdfs IS NOT NULL AND pdfs !=''");
           
        }
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }

    public function getFreeVideosBySubjectNew($subjectCatId, $type)
    {
        if ($type == 'video') {
            $results = $this->AdminDetails->fetchCol_Con('free_videos_tb', 'id,title,videos,description', "status=1 and subject_category=$subjectCatId");
        } else {
            $results = $this->AdminDetails->fetchCol_Con('free_videos_tb', 'id,title,pdfs,description', "status=1 and subject_category=$subjectCatId");
        }

        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function videosNew($id, $type)
    {
        if ($type == 'video') {
            $query = $this->db->query("select id,category,title,description,videos from webiste_videos_tb where video_categories='$id' and status='1' and videos IS NOT NULL AND videos !=''");
        } else {
            $query = $this->db->query("select id,category,title,description,pdfs from webiste_videos_tb where video_categories='$id' and status='1' and pdfs IS NOT NULL AND pdfs !=''");
        }
        $results = $query->result();

        $collection = array(
            'error' => false,
            'message' => 'Request  Completed Successfully',
            'data' => $results
        );
        echo json_encode($collection);
    }
    public function sendOtp($number)
    {


        //send otp 
        $toNumber = "+91" . $number;
        $otp = rand(1000, 9999);
        $apiKey = '5be01103-2857-11ee-addf-0200cd936042';
        $sendSms = 'https://2factor.in/API/V1/' . $apiKey . '/SMS/' . $toNumber . '/' . $otp;


        //send otp 
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $sendSms,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_POSTFIELDS => "",
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded"
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            // echo "cURL Error #:" . $err;

            $collection = array(
                'error' => true,
                'message' => 'Some error occured.',
                'data' => $err
            );
            echo json_encode($collection);
        } else {
            $response;
            $data = array(
                'otp' => $otp
            );
            $check = $this->AdminDetails->fetchCol_Con("mst_user", "id", "phone=$number");

            if ($check[0]->id != '') {
                $update = $this->AdminDetails->updateDetails("mst_user", $data, "phone=$number");
                $collection = array(
                    'error' => false,
                    'message' => 'OTP sended successfully.',
                    'data' => $response
                );
            } else {
                $collection = array(
                    'error' => false,
                    'message' => 'Mobile number is not exists.',

                );
            }
            echo json_encode($collection, true);
        }
        //end 
    }
    public function trending()
    {

        $results = $this->AdminDetails->fetchCol_Con('course_menu_tb', "id,course_name,courses,images", "status=1 and popular=1 order by position asc");
        $collection = array(
            'error' => false,
            'message' => 'Request completed successfully',
            'data' => $results,
        );
        echo json_encode($collection);
    }
    public function carousel()
    {
        $results = $this->AdminDetails->fetchCol_Con('carousel_tb', "id,title,courses,images,imagealt", "status=1 order by position asc");
        $collection = array(
            'error' => false,
            'message' => 'Request completed successfully',
            'data' => $results,
        );
        echo json_encode($collection);
    }
    public function carouselCourses($cid)
    {
        $results = $this->AdminDetails->fetchCol_Con("carousel_tb", "courses,title,id", "id=$cid and status='1'");
        $course_id = explode(",", $results[0]->courses);
        $all_courses = array();
        for ($i = 0; $i < count($course_id); $i++) {
            $course = $this->AdminDetails->fetchCon("video_subject_tb", "id=$course_id[$i] order by position ASC");
            array_push($all_courses, $course[0]);
        }
        //sorting
        function toLowerCase($a)
        {
            return strtolower($a);
        }
        $sortArray = array_map("toLowerCase", array_column($all_courses, 'position'));
        array_multisort($sortArray, SORT_ASC, $all_courses);

        //endsorting
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $all_courses,

        );
        echo json_encode($collection);
    }

    public function notice()
    {
          $results = $this->AdminDetails->fetchCol_Con("notice_tb", "id,title,url", "status='1'");
        
        // $notice[] = array(
        //     'id' => 1,
        //     'title' => 'Free Register now for new batch of 11th JPSC.',
        //     'url' => 'https://careerfoundation.org.in/scholorship-test'
        // );

        //endsorting
        $collection = array(
            'error' => false,
            'message' => 'Requestd  Completed Successfully',
            'data' => $results,

        );
        echo json_encode($collection);
    }

    public function loginInfo($number)
    {

        $row = $this->AdminDetails->fetchCol_Con("auth_history", "id,mobileNumber,deviceId,fcmToken", "mobileNumber=$number order by id desc limit 1");
        if ($row) {
            $collection = array(
                'error' => false,
                'message' => 'Requestd Completed Successfully',
                'data' => $row,

            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'No Record found',


            );
        }

        echo json_encode($collection);
    }
    public function downloadYoutubeVideos()
    {

      
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $videoId = $this->input->post('videoId');
            $curl = curl_init();

            curl_setopt_array($curl, [
                CURLOPT_URL => "https://youtube86.p.rapidapi.com/api/youtube/links",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode([
                    'url' => 'https://www.youtube.com/watch?v=' . $videoId
                ]),
                CURLOPT_HTTPHEADER => [
                    "Content-Type: application/json",
                    "X-Forwarded-For: 70.41.3.18",
                    "x-rapidapi-host: youtube86.p.rapidapi.com",
                    "x-rapidapi-key: c38e194d80msh337204533f733dcp16c7e7jsn93e0385590c1"
                ],
            ]);

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
                echo "cURL Error #:" . $err;
                $res = array(
                    'success' => false,
                    'data' => 'Some error occured.',
                );
            } else {
                $data = json_decode($response, true);

                // Step 3: Access the `urls` array
                   $urls = $data[0]['urls'];
                // Step 4: Access the first URL in the `urls` array
                     $firstUrl = $urls[0]['url'];
                // Display the first URL

                $res = array(
                    'success' => true,
                    'data' => $firstUrl,
                );
            }
           
           echo json_encode($res);
        }
    }
      public function getCoupons($courseId, $couponCode)
    {
        $courseId;
       $couponCode= strtok($couponCode, '-');
        // $checkCoupon = $this->AdminDetails->fetchCol_Con('video_subject_tb', 'id,price', "id=$courseId and couponCode='$couponCode'");
         $this->db->select('id, price');
        $this->db->from('video_subject_tb');
        $this->db->where('id', $courseId);
        $this->db->where("FIND_IN_SET('".$this->db->escape_str($couponCode)."', couponCode) >", 0, false);
        $query = $this->db->get();
        
        $checkCoupon = $query->result();
        if ($checkCoupon[0]->id) {
            $coupon = $this->AdminDetails->fetchCol_Con('coupon', 'id,title,off,validFrom,validTill,limitOfUse', "couponCode='$couponCode' and status=1");
            $price = $checkCoupon[0]->price;
            $discount = $coupon[0]->off;

            $payableAmount = round($price - ($price * $discount / 100));
            $collection = array(
                'data' => $coupon[0],
                'payableAmount' => $payableAmount,
                'error' => false,
                'message' => 'Invalid coupon code entered',
            );
        } else {
            $collection = array(
                'error' => true,
                'message' => 'Invalid coupon code entered',
            );
        }
        echo json_encode($collection);
    }
    
     // Function to fetch payment information
    public function capturePayment($payment_id,$amount)
    {
        try {
            // Fetch payment details using the payment ID
            $payment = $this->api->payment->fetch($payment_id);
               $paystatus = $payment['status'];
            if ($paystatus == 'authorized') {
                $payments = $this->api->payment->fetch($payment_id)->capture(array('amount'=>($amount*100),'currency'=>'INR'));
               
        }
            // Convert the payment details to an array

        } catch (\Razorpay\Api\Errors\BadRequestError $e) {
            // Handle any errors (e.g., invalid payment ID)
            log_message('error', 'Razorpay Error: ' . $e->getMessage());
           // return false;
        }
    }
}
