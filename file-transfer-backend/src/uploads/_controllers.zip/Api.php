<?php
defined('BASEPATH') or exit('No direct script access allowed');
error_reporting(0);
class Api extends CI_Controller
{

    public function __construct()
    {
        Parent::__construct();
        $this->load->database();
        $this->load->model('Basic_operation', 'basic_operation', TRUE);
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method == "OPTIONS") {
            die();
        }
    }

    public function login()
    {

        $api_url = site_url() . "app/login";

        $form_data = array(
            'email'  => $this->input->post('email'),
            'pass'   => md5($this->input->post('password')),
            'fcm_token' => $this->input->post('deviceToken'),
            'device_type' => $this->input->post('device_type'),
            'deviceId' => $this->input->post('deviceId')
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }



    public function verifyOTP()
    {
        $api_url = site_url() . "app/verifyOTP";
        $form_data = array(
            'mobile'  => $this->input->post('mobile'),
            'otp' => $this->input->post('otp'),
            'fcm_token' => $this->input->post('fcm_token'),
            'device_type' => $this->input->post('device_type'),
            'deviceId' => $this->input->post('deviceId'),
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    // Function to generate OTP 
    public function generateNumericOTP($n)
    {
        $generator = "1357902468";
        $otp = "";
        for ($i = 1; $i <= $n; $i++) {
            $otp .= substr($generator, (rand() % (strlen($generator))), 1);
        }

        $chkOTP = $this->basic_operation->matchedRowCount('users', array('verify_otp =' => $otp));
        if ($chkOTP > 0) {
            $this->generateNumericOTP(6);
        } else {
            return $otp;
        }
    }
    public function logout()
    {

        $api_url = site_url() . "app/logout";
        $form_data = array(
            'user_id'  => $this->input->post('user_id'),
            'device_type' => $this->input->post('device_type')
        );

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function forgot()
    {

        $api_url = "https://careerfoundation.org.in/home/forgot";
        $form_data = array(
            'email'  => trim($this->input->post('email')),
        );


        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }


    /* *****************************************  Users APIs ****************************************** */

    public function UserLogin()
    {

        $api_url = site_url() . "users/login";
        $form_data = array(
            'email'  => $this->input->post('email'),
            'password'   => $this->input->post('password'),
            'fcm_token' => $this->input->post('fcm_token')
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function UserLogout()
    {

        $api_url = site_url() . "users/logout";
        $form_data = array(
            'token'  => $this->input->post('token'),
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function UserForgot()
    {

        $api_url = site_url() . "users/forgot";
        $form_data = array(
            'email'  => $this->input->post('email'),
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function checkEmailAvailibility()
    {

        $api_url = site_url() . "data/checkEmailAvailibility";
        $form_data = array(
            'email'  => $this->input->post('email'),
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }


    /* ***************************************** Home Pages APIs *******************************************/

    public function getHomeData()
    {
        $api_url = site_url() . "app/getHomeData";

        $client = curl_init($api_url);
        $form_data = array(
            'user_id' => $this->input->post('user_id'),
            'device_id' => $this->input->post('device_id')
        );
        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function getAllCourse()
    {

        $api_url = site_url() . "app/getAllSubject";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }


    public function getAllUser()
    {

        $api_url = site_url() . "app/getAllUser";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function getAllCategoryProduct()
    {

        $api_url = site_url() . "app/getAllCategoryProduct";
        $client = curl_init($api_url);
        $form_data = array(
            'category_id' => $this->input->post('category_id'),
            'user_id' => $this->input->post('user_id'),
            'page' => $this->input->post('page'),
            'type' => $this->input->post('type'),
            'device_id' => $this->input->post('device_id'),
            'iosall' => $this->input->post('iosall'),
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }


    public function getPromotionalCategoryProduct()
    {

        $api_url = site_url() . "app/getPromotionalCategoryProduct";
        $client = curl_init($api_url);
        $form_data = array(
            'category_id' => $this->input->post('category_id'),
            'user_id' => $this->input->post('user_id'),
            'page' => $this->input->post('page'),
            'device_id' => $this->input->post('device_id'),
            'iosall' => $this->input->post('iosall'),
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function getAllSubCategory($id)
    {

        $api_url = site_url() . "app/getAllSubCategory/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }


    public function getMessages()
    {
        $api_url = site_url() . "app/getMessages";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }



    public function Profile()
    {
        $api_url = site_url() . "app/Profile";
        $form_data = array(
            'user_id'   => $this->input->post('email'),
            'device_type' => $this->input->post('device_type')
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function updateProfile()
    {
        $api_url = site_url() . "app/updateProfile";
        $form_data = array(
            'user_id'   => $this->input->post('id'),
            'name' => $this->input->post('name'),
            'address' => $this->input->post('address'),
            'mobile' => $this->input->post('mobile'),

        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function changePassword()
    {
        $api_url = site_url() . "app/changePassword";
        $form_data = array(
            'id'   => $this->input->post('user_id'),
            'password' => $this->input->post('current_password'),
            'new_password' => $this->input->post('new_password'),
            'confirm_password' => $this->input->post('confirm_password'),
            'device_type' => $this->input->post('device_id')
        );

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function search()
    {

        $api_url = site_url() . "app/search";
        $form_data = array(
            'keywords' => $this->input->post('keywords'),

        );

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

   

    

    public function SetNotificationKeys()
    {
        $api_url = site_url() . "app/SetNotificationKeys";
        $form_data = array(
            'user_id'   => $this->input->post('user_id'),
            'pending'   => $this->input->post('pending'),
            'processing' => $this->input->post('processing'),
            'delivered' => $this->input->post('delivered'),
            'cancelled' => $this->input->post('cancelled'),
            'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function GetNotificationKeys()
    {
        $api_url = site_url() . "app/GetNotificationKeys";
        $form_data = array(
            'user_id'   => $this->input->post('user_id'),
            'device_id' => $this->input->post('device_id')
        );

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }


    public function getFreeVideos()
    {

        $api_url = site_url() . "app/getFreeVideos";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function getVacancy()
    {

        $api_url = site_url() . "app/getVacancy";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function getBooks()
    {

        $api_url = site_url() . "app/getBooks";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function getMypurchase($id)
    {

        $api_url = site_url() . "app/getMypurchase/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function getSubjectById($id)
    {

        $api_url = site_url() . "app/getSubject/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function payment($cid, $uid)
    {

        $api_url = site_url() . "app/payment/$cid/$uid";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function getSubjectVideo($cid, $sid)
    {

        $api_url = site_url() . "app/getSubjectVideo/$cid/$sid";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function getSubjectVideoNew($cid, $sid, $type)
    {

        $api_url = site_url() . "app/getSubjectVideoNew/$cid/$sid/$type";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function thankyou($cid, $uid)
    {

        $api_url = site_url() . "app/thankyou/$cid/$uid";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }


    public function categories()
    {

        $api_url = site_url() . "app/categories";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function courses($cid, $userId)
    {

        $api_url = site_url() . "app/courses/$cid/$userId";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function levelbycourse($subcat)
    {

        $api_url = site_url() . "app/coursesbycategory/$subcat";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function SubjectVideosWithCat($cid, $sid, $subcat)
    {

        $api_url = site_url() . "app/SubjectVideosWithCat/$cid/$sid/$subcat";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function subjectfolder($subcat)
    {

        $api_url = site_url() . "app/subjectfolder/$subcat";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function subjectbylevel($subjectid)
    {

        $api_url = site_url() . "app/subjectbylevel/$subjectid";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function coursesbycategory($id)
    {

        $api_url = site_url() . "app/courses/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function videosbysubjectfolder($id)
    {

        $api_url = site_url() . "app/videosbysubjectfolder/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function videos($id)
    {

        $api_url = site_url() . "app/videos/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function checkdeviceId($userid, $deviceId)
    {

        $api_url = site_url() . "app/checkdeviceId/$userid/$deviceId";


        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;

        if (json_decode($response)->status == '403') {
            http_response_code(403);
        }
    }
    public function homepage()
    {

        $api_url = site_url() . "app/homepage";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function livestream($id)
    {

        $api_url = site_url() . "app/livestream/$id";

        $client = curl_init($api_url);

        // curl_setopt($client, CURLOPT_POST, true);

        // curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function aboutus()
    {

        $api_url = site_url() . "app/aboutus";

        $client = curl_init($api_url);

        // curl_setopt($client, CURLOPT_POST, true);

        // curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function razorpay()
    {
        $api_url = site_url() . "app/razorpay";
        $form_data =  $_POST;
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function sendmessage()
    {
        $api_url = site_url() . "app/sendmessage";
        $form_data =  $_POST;

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function chatmessage($id)
    {

        $api_url = site_url() . "app/chatmessage/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function sendGroupMessage()
    {
        $api_url = site_url() . "app/sendGroupMessage";
        $form_data =  $_POST;
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function chatGroupMessage($id)
    {

        $api_url = site_url() . "app/chatGroupMessage/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function lastGroupMessage($groupId, $id)
    {

        $api_url = site_url() . "app/lastGroupMessage/$groupId/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    //send live stream message


    public function chatLiveStreamMessage($id)
    {

        $api_url = site_url() . "app/chatLiveStreamMessage/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function sendLiveStreamMessage()
    {
        $api_url = site_url() . "app/sendLiveStreamMessage";
        $form_data =  $_POST;
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function lastLiveStreamMessage($groupId, $id)
    {

        $api_url = site_url() . "app/lastLiveStreamMessage/$groupId/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    //end live stream message

    public function demovideos($cid)
    {

        $api_url = site_url() . "app/demovideos/$cid";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function demoVideosNew($cid, $type)
    {

        $api_url = site_url() . "app/demovideosnew/$cid/$type";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function teachers()
    {

        $api_url = site_url() . "app/teachers";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function connection()
    {

        $api_url = site_url() . "app/connection";

        $form_data = array(
            'sid'  => trim($this->input->post('sid')),
            'tid' => trim($this->input->post('tid'))
        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function demosubject()
    {

        $api_url = site_url() . "app/demosubject";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function demoSubjectCategory($id)
    {

        $api_url = site_url() . "app/demoSubjectCategory/$id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function getFreeVideosBySubject($subjectCatId)
    {

        $api_url = site_url() . "app/getFreeVideosBySubject/$subjectCatId";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function checkdiscount($uid, $new_course_id)
    {

        $api_url = site_url() . "app/checkdiscount/$uid/$new_course_id";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function getFreeVideosBySubjectNew($subjectCatId, $type)
    {

        $api_url = site_url() . "app/getFreeVideosBySubject/$subjectCatId/$type";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function videosNew($id, $type)
    {

        $api_url = site_url() . "app/videosNew/$id/$type";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function sendOtp($number)
    {
        $api_url = site_url() . "app/sendOtp/$number";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function trending()
    {

        $api_url = site_url() . "app/trending";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function carousel()
    {

        $api_url = site_url() . "app/carousel";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function carouselCourses($cid)
    {

        $api_url = site_url() . "app/carouselCourses/$cid";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    public function notice()
    {

        $api_url = site_url() . "app/notice";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }

    public function loginInfo($number)
    {

        $api_url = site_url() . "app/loginInfo/$number";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
      public function downloadYoutubeVideos()
    {
        $api_url = site_url() . "app/downloadYoutubeVideos";
        $form_data = array(
            'videoId'  => $this->input->post('videoId'),

        );
        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    
     public function getCoupons($courseId,$couponCode)
    {

        $api_url = site_url() . "app/getCoupons/$courseId/$couponCode";

        $client = curl_init($api_url);

        curl_setopt($client, CURLOPT_POST, true);

        curl_setopt($client, CURLOPT_POSTFIELDS, false);

        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($client);

        curl_close($client);

        echo $response;
    }
    
}
